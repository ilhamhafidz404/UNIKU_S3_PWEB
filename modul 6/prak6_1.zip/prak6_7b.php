<?php
    $i=0;
    while($i<=4)
     {
        echo "$i <BR>";
        $i++;
    }
?>