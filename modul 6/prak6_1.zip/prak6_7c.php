<?php
     $i=0;
     do
    {
        echo "$i <BR>";
        $i++;
    }
    while($i<=4);
?>