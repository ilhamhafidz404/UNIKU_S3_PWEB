<!DOCTYPE html> 
<html> 
<head> 
    <title>Modul 6 Praktikum 1</title> 
</head> 
<body text="white" bgcolor="pink"> 
    <?php echo "<center> 
    <font color='yellow' size='6'>Uniku Jaya</font> 
    <br><h1>FKOM Jaya</h1><br> 
    <font color='blue' size='5'><i>Teknik Informatika</i> <b>Prestasi</b></font>!! 
    </center>"; 
    ?> 
</body> 